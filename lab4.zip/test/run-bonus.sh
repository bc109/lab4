docker build -t hello:v2 .
docker run -d  --name=webapp -p 0:8080 hello:v2
host_name=$(docker inspect webapp | jq '.[].NetworkSettings.Ports."8080/tcp"[].HostPort' | tr -d '"')
echo Your application is now avaliable at http://localhost:$host_name
